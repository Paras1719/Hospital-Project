"use client"

import { Label } from "@/components/ui/label"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { History, Search, FileText, Calendar, User, ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Skeleton } from "@/components/ui/skeleton"

// Define types for better data structure
interface Visit {
  id: number
  date: string
  diagnosis: string
  prescription: string
  notes: string
  doctor: string
  status: string
}

interface PatientHistoryData {
  id: number
  name: string
  age: number
  gender: string
  phone: string
  totalVisits: number
  firstVisit: string
  lastVisit: string
  conditions: string[]
  visits: Visit[]
  avatar?: string
}

const initialPatientHistories: PatientHistoryData[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    age: 34,
    gender: "Female",
    phone: "+1 (555) 123-4567",
    totalVisits: 8,
    firstVisit: "2023-06-15",
    lastVisit: "2024-01-15",
    conditions: ["Hypertension", "Anxiety"],
    visits: [
      {
        id: 101,
        date: "2024-01-15",
        diagnosis: "Hypertension follow-up",
        prescription: "Lisinopril 10mg, once daily",
        notes:
          "Blood pressure stable at 120/80 mmHg. Patient reports good adherence to medication. Continue current regimen and schedule follow-up in 3 months.",
        doctor: "Dr. Smith",
        status: "Completed",
      },
      {
        id: 102,
        date: "2023-12-20",
        diagnosis: "Anxiety disorder",
        prescription: "Sertraline 50mg, once daily",
        notes:
          "Patient reports 50% reduction in anxiety symptoms. Sleeping better. Mild nausea reported - advised to take with food.",
        doctor: "Dr. Johnson",
        status: "Completed",
      },
      {
        id: 103,
        date: "2023-11-10",
        diagnosis: "Hypertension",
        prescription: "Lisinopril 5mg, once daily",
        notes:
          "Initial diagnosis with BP 140/90 mmHg. Recommended lifestyle changes including reduced sodium intake and regular exercise.",
        doctor: "Dr. Smith",
        status: "Completed",
      },
    ],
    avatar: "/avatars/patient-1.jpg",
  },
  {
    id: 2,
    name: "Michael Brown",
    age: 45,
    gender: "Male",
    phone: "+1 (555) 234-5678",
    totalVisits: 12,
    firstVisit: "2023-03-10",
    lastVisit: "2024-01-14",
    conditions: ["Diabetes Type 2", "High Cholesterol"],
    visits: [
      {
        id: 201,
        date: "2024-01-14",
        diagnosis: "Diabetes Type 2 management",
        prescription: "Metformin 1000mg twice daily, Atorvastatin 20mg",
        notes:
          "HbA1c improved to 7.2% from 8.1%. Cholesterol levels within normal range. Continue current regimen with quarterly monitoring.",
        doctor: "Dr. Lee",
        status: "Completed",
      },
      {
        id: 202,
        date: "2023-12-15",
        diagnosis: "Diabetes and cholesterol check",
        prescription: "Metformin 500mg twice daily, Atorvastatin 10mg",
        notes:
          "Blood sugar levels improving but still elevated. Increased Metformin dosage. Recommended dietary consultation.",
        doctor: "Dr. Lee",
        status: "Completed",
      },
    ],
    avatar: "/avatars/patient-2.jpg",
  },
]

export default function PatientHistory() {
  const [patientHistories, setPatientHistories] = useState<PatientHistoryData[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<number | null>(1)
  const [sortBy, setSortBy] = useState("lastVisit")
  const [expandedVisits, setExpandedVisits] = useState<Record<number, boolean>>({})
  const [viewMode, setViewMode] = useState<"list" | "grid">("list") // Not fully implemented for grid view, but kept for future expansion
  const [isLoading, setIsLoading] = useState(true)

  // Simulate fetching data from backend
  useEffect(() => {
    setIsLoading(true)
    // In a real application, you would fetch data here:
    // fetch('/api/patient-histories').then(res => res.json()).then(data => {
    //   setPatientHistories(data);
    //   setIsLoading(false);
    // });
    const timer = setTimeout(() => {
      setPatientHistories(initialPatientHistories)
      setIsLoading(false)
    }, 1000) // Simulate network delay
    return () => clearTimeout(timer)
  }, [])

  const filteredPatients = patientHistories.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.conditions.some((condition) => condition.toLowerCase().includes(searchTerm.toLowerCase())) ||
      patient.phone.includes(searchTerm),
  )

  const sortedPatients = [...filteredPatients].sort((a, b) => {
    switch (sortBy) {
      case "name":
        return a.name.localeCompare(b.name)
      case "lastVisit":
        return new Date(b.lastVisit).getTime() - new Date(a.lastVisit).getTime()
      case "totalVisits":
        return b.totalVisits - a.totalVisits
      default:
        return 0
    }
  })

  const selectedPatientData = selectedPatient ? patientHistories.find((p) => p.id === selectedPatient) : null

  const toggleVisitExpansion = (visitId: number) => {
    setExpandedVisits((prev) => ({
      ...prev,
      [visitId]: !prev[visitId],
    }))
  }

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: "numeric", month: "short", day: "numeric" }
    return new Date(dateString).toLocaleDateString("en-US", options)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Patient History</h1>
          <p className="text-slate-400">Complete medical records and visit history</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setViewMode(viewMode === "list" ? "grid" : "list")}
            className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
          >
            {viewMode === "list" ? "Grid View" : "List View"}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient List */}
        <Card className="lg:col-span-1 bg-slate-800/80 border-slate-700">
          <CardHeader className="border-b border-slate-700 pb-4">
            <CardTitle className="flex items-center gap-2 text-white">
              <User className="h-5 w-5 text-emerald-400" />
              Patients
            </CardTitle>
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search patients..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                />
              </div>
              <div className="flex gap-2">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="name" className="text-white hover:bg-slate-700">
                      Name
                    </SelectItem>
                    <SelectItem value="lastVisit" className="text-white hover:bg-slate-700">
                      Last Visit
                    </SelectItem>
                    <SelectItem value="totalVisits" className="text-white hover:bg-slate-700">
                      Visit Count
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-2">
              {isLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div
                      key={i}
                      className="p-3 border border-slate-700 rounded-lg bg-slate-700/50 flex items-center gap-3"
                    >
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-3 w-1/2" />
                      </div>
                      <Skeleton className="h-6 w-6 rounded-full" />
                    </div>
                  ))}
                </div>
              ) : sortedPatients.length === 0 ? (
                <div className="py-8 text-center text-slate-400">No patients found matching your criteria</div>
              ) : (
                sortedPatients.map((patient) => (
                  <div
                    key={patient.id}
                    className={cn(
                      "p-3 rounded-lg cursor-pointer transition-colors border",
                      selectedPatient === patient.id
                        ? "bg-emerald-500/20 border-emerald-500/30"
                        : "bg-slate-700/50 border-slate-600 hover:bg-slate-700",
                    )}
                    onClick={() => setSelectedPatient(patient.id)}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={patient.avatar || "/placeholder.svg"} />
                        <AvatarFallback className="bg-emerald-500/20 text-emerald-400">
                          {patient.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium truncate text-white">{patient.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs bg-slate-600/50 text-slate-300 border-slate-500">
                            {patient.gender}, {patient.age}
                          </Badge>
                          <span className="text-xs text-slate-400 truncate">{patient.conditions[0]}</span>
                        </div>
                      </div>
                      <Badge variant="secondary" className="shrink-0 bg-slate-600/50 text-slate-300 border-slate-500">
                        {patient.totalVisits}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Patient Details */}
        <div className="lg:col-span-2 space-y-6">
          {isLoading ? (
            <div className="space-y-6">
              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <Skeleton className="h-6 w-1/2" />
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <div key={i} className="space-y-2">
                        <Skeleton className="h-3 w-1/3" />
                        <Skeleton className="h-4 w-2/3" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <Skeleton className="h-6 w-1/2" />
                </CardHeader>
                <CardContent className="pt-6">
                  <Skeleton className="h-8 w-full" />
                </CardContent>
              </Card>
              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <Skeleton className="h-6 w-1/2" />
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  {Array.from({ length: 2 }).map((_, i) => (
                    <div key={i} className="p-4 border border-slate-700 rounded-lg bg-slate-700/50 space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-3 w-3/4" />
                      <Skeleton className="h-16 w-full" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          ) : selectedPatientData ? (
            <>
              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <CardTitle className="flex items-center gap-2 text-white">
                    <FileText className="h-5 w-5 text-emerald-400" />
                    Patient Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-slate-400">Name</p>
                      <p className="font-medium text-slate-300">{selectedPatientData.name}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-slate-400">Age/Gender</p>
                      <p className="font-medium text-slate-300">
                        {selectedPatientData.age} / {selectedPatientData.gender}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-slate-400">Phone</p>
                      <p className="font-medium text-slate-300">{selectedPatientData.phone}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-slate-400">Total Visits</p>
                      <p className="font-medium text-slate-300">{selectedPatientData.totalVisits}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <CardTitle className="flex items-center gap-2 text-white">
                    <History className="h-5 w-5 text-teal-400" />
                    Medical Conditions
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="flex flex-wrap gap-2">
                    {selectedPatientData.conditions.map((condition) => (
                      <Badge
                        key={condition}
                        variant="outline"
                        className="text-red-400 bg-red-500/20 hover:bg-red-500/30 border-red-500/30"
                      >
                        {condition}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Calendar className="h-5 w-5 text-cyan-400" />
                    Visit History
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    {selectedPatientData.visits.length === 0 ? (
                      <div className="py-6 text-center text-slate-400">No visit history available.</div>
                    ) : (
                      selectedPatientData.visits.map((visit) => (
                        <div
                          key={visit.id}
                          className={cn(
                            "overflow-hidden transition-all duration-200",
                            expandedVisits[visit.id] && "border-emerald-500",
                          )}
                        >
                          <Card
                            className={cn(
                              "bg-slate-700/50 border-slate-600 hover:bg-slate-700 transition-colors",
                              expandedVisits[visit.id] && "bg-slate-700 border-emerald-500/50",
                            )}
                          >
                            <div
                              className="flex items-center justify-between p-4 cursor-pointer"
                              onClick={() => toggleVisitExpansion(visit.id)}
                            >
                              <div className="flex items-center gap-4">
                                <div className="p-2 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                                  <Calendar className="h-5 w-5 text-emerald-400" />
                                </div>
                                <div>
                                  <h3 className="font-medium text-white">{formatDate(visit.date)}</h3>
                                  <p className="text-sm text-slate-400">{visit.diagnosis}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge
                                  variant="outline"
                                  className="text-xs bg-slate-600/50 text-slate-300 border-slate-500"
                                >
                                  {visit.doctor}
                                </Badge>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0 text-slate-400 hover:text-white"
                                >
                                  {expandedVisits[visit.id] ? (
                                    <ChevronUp className="h-4 w-4" />
                                  ) : (
                                    <ChevronDown className="h-4 w-4" />
                                  )}
                                </Button>
                              </div>
                            </div>
                            {expandedVisits[visit.id] && (
                              <div className="border-t border-slate-600 p-4 space-y-4 transition-all duration-200 ease-in-out">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                    <Label className="text-slate-300">Diagnosis</Label>
                                    <p className="font-medium text-slate-300">{visit.diagnosis}</p>
                                  </div>
                                  <div className="space-y-2">
                                    <Label className="text-slate-300">Prescription</Label>
                                    <p className="font-medium text-emerald-400">{visit.prescription}</p>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <Label className="text-slate-300">Notes</Label>
                                  <p className="text-slate-400 whitespace-pre-line">{visit.notes}</p>
                                </div>
                              </div>
                            )}
                          </Card>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card className="h-full bg-slate-800/80 border-slate-700">
              <CardContent className="flex flex-col items-center justify-center h-[400px] text-slate-400">
                <User className="h-12 w-12 text-slate-500 mb-4" />
                <h3 className="text-lg font-medium mb-1 text-white">No patient selected</h3>
                <p className="text-sm text-center">
                  Select a patient from the list to view their complete medical history
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
