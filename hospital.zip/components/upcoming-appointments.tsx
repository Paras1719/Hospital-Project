import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, User, Calendar } from "lucide-react"

const appointments = [
  {
    id: 1,
    patient: "Sarah Johnson",
    time: "09:00 AM",
    type: "Consultation",
    status: "confirmed",
  },
  {
    id: 2,
    patient: "Michael Brown",
    time: "10:30 AM",
    type: "Follow-up",
    status: "confirmed",
  },
  {
    id: 3,
    patient: "Emily Davis",
    time: "02:00 PM",
    type: "Check-up",
    status: "pending",
  },
  {
    id: 4,
    patient: "Robert Wilson",
    time: "03:30 PM",
    type: "Consultation",
    status: "confirmed",
  },
]

export default function UpcomingAppointments() {
  return (
    <Card className="bg-slate-800/80 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Calendar className="h-5 w-5 text-emerald-400" />
          Today's Appointments
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {appointments.map((appointment) => (
            <div
              key={appointment.id}
              className="flex items-center justify-between p-3 border border-slate-600 rounded-lg bg-slate-700/50 hover:bg-slate-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-500/20 rounded-full border border-emerald-500/30">
                  <User className="h-4 w-4 text-emerald-400" />
                </div>
                <div>
                  <p className="font-medium text-white">{appointment.patient}</p>
                  <p className="text-sm text-slate-400 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {appointment.time}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-slate-300">{appointment.type}</p>
                <Badge
                  variant={appointment.status === "confirmed" ? "default" : "secondary"}
                  className={
                    appointment.status === "confirmed"
                      ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                      : "bg-amber-500/20 text-amber-400 border-amber-500/30"
                  }
                >
                  {appointment.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
