"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { FileText, Plus, Printer, Download, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Define types for better data structure
interface Medication {
  name: string
  dosage: string
  frequency: string
  duration: string
  notes: string
}

interface Prescription {
  patientName: string
  age: string
  date: string
  diagnosis: string
  medications: Medication[]
  instructions: string
  followUp: string
}

interface PrescriptionHeader {
  clinicName: string
  doctorName: string
  qualification: string
  address: string
  phone: string
  email: string
  regNumber: string
}

export default function PrescriptionManager() {
  const [isPrintPreview, setIsPrintPreview] = useState(false)
  const [prescription, setPrescription] = useState<Prescription>({
    patientName: "",
    age: "",
    date: new Date().toISOString().split("T")[0],
    diagnosis: "",
    medications: [{ name: "", dosage: "", frequency: "", duration: "", notes: "" }],
    instructions: "",
    followUp: "",
  })

  const [prescriptionHeader, setPrescriptionHeader] = useState<PrescriptionHeader>({
    clinicName: "Heart Care Clinic",
    doctorName: "Dr. John Smith",
    qualification: "MBBS, MD (Cardiology)",
    address: "123 Medical Street, Health City",
    phone: "+1 (555) 123-4567",
    email: "dr.johnsmith@healthcare.com",
    regNumber: "REG123456",
  })

  const commonMedications = [
    "Paracetamol",
    "Ibuprofen",
    "Amoxicillin",
    "Lisinopril",
    "Atorvastatin",
    "Metformin",
    "Omeprazole",
    "Albuterol",
  ]

  const addMedication = () => {
    setPrescription({
      ...prescription,
      medications: [...prescription.medications, { name: "", dosage: "", frequency: "", duration: "", notes: "" }],
    })
  }

  const updateMedication = (index: number, field: keyof Medication, value: string) => {
    const updatedMedications = prescription.medications.map((med, i) =>
      i === index ? { ...med, [field]: value } : med,
    )
    setPrescription({ ...prescription, medications: updatedMedications })
  }

  const removeMedication = (index: number) => {
    setPrescription({
      ...prescription,
      medications: prescription.medications.filter((_, i) => i !== index),
    })
  }

  // This HTML is for the print preview and will retain a light background for printability.
  // The in-app preview will be styled dark.
  const generatePrescriptionHTML = () => {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Prescription</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
            .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
            .clinic-name { font-size: 24px; font-weight: bold; color: #2563eb; }
            .doctor-info { margin: 10px 0; }
            .patient-info { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; border: 1px solid #eee; }
            .prescription-body { margin: 20px 0; }
            .medication { border: 1px solid #ddd; padding: 10px; margin: 10px 0; border-radius: 5px; }
            .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .signature { margin-top: 50px; border-top: 1px solid #333; width: 200px; padding-top: 10px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="clinic-name">${prescriptionHeader.clinicName}</div>
            <div class="doctor-info">
              <strong>${prescriptionHeader.doctorName}</strong><br>
              ${prescriptionHeader.qualification}<br>
              Reg. No: ${prescriptionHeader.regNumber}
            </div>
            <div>${prescriptionHeader.address}</div>
            <div>Phone: ${prescriptionHeader.phone} | Email: ${prescriptionHeader.email}</div>
          </div>
          
          <div class="patient-info">
            <strong>Patient Information:</strong><br>
            Name: ${prescription.patientName}<br>
            Age: ${prescription.age}<br>
            Date: ${new Date(prescription.date).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </div>
          
          <div class="prescription-body">
            <strong>Diagnosis:</strong> ${prescription.diagnosis}<br><br>
            
            <strong>Medications:</strong>
            <table>
              <tr>
                <th>Medication</th>
                <th>Dosage</th>
                <th>Frequency</th>
                <th>Duration</th>
                <th>Notes</th>
              </tr>
              ${prescription.medications
                .map(
                  (med) => `
                <tr>
                  <td>${med.name}</td>
                  <td>${med.dosage}</td>
                  <td>${med.frequency}</td>
                  <td>${med.duration}</td>
                  <td>${med.notes}</td>
                </tr>
              `,
                )
                .join("")}
            </table>
            
            <br><strong>Instructions:</strong><br>
            ${prescription.instructions.replace(/\n/g, "<br>")}
            
            <br><br><strong>Follow-up:</strong> ${prescription.followUp}
          </div>
          
          <div class="footer">
            <div class="signature">${prescriptionHeader.doctorName}</div>
            <p>This prescription is valid for 6 months from the date of issue.</p>
            <p>For any queries, please contact the clinic.</p>
          </div>
        </body>
      </html>
    `
  }

  const printPrescription = () => {
    const printWindow = window.open("", "_blank")
    printWindow?.document.write(generatePrescriptionHTML())
    printWindow?.document.close()
    printWindow?.print()
  }

  const saveAsPDF = () => {
    // In a real implementation, you would use a library like html2pdf.js or send to a backend service
    // to generate a PDF from the HTML.
    alert("PDF generation would be implemented here (client-side or server-side).")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Prescription Manager</h1>
          <p className="text-slate-400">Create and manage patient prescriptions</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setIsPrintPreview(!isPrintPreview)}
            variant={isPrintPreview ? "default" : "outline"}
            className={cn(
              isPrintPreview
                ? "bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
                : "border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent",
            )}
          >
            {isPrintPreview ? "Back to Editor" : "Preview"}
          </Button>
          <Button
            onClick={printPrescription}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
          >
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          <Button
            onClick={saveAsPDF}
            className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
          >
            <Download className="h-4 w-4 mr-2" />
            Save PDF
          </Button>
        </div>
      </div>

      <div className="transition-all duration-300 ease-in-out overflow-hidden">
        {isPrintPreview ? (
          <Card className="p-6 bg-slate-800/80 border-slate-700">
            {/* This div will be styled to fit the dark theme for in-app preview */}
            <div
              className="p-8 rounded-lg text-slate-300"
              style={{
                background: "linear-gradient(to bottom right, #1e293b, #0f172a)", // Dark background for in-app preview
                border: "1px solid #334155",
              }}
            >
              <div className="text-center border-b-2 border-slate-600 pb-4 mb-6">
                <div className="text-2xl font-bold text-emerald-400">{prescriptionHeader.clinicName}</div>
                <div className="mt-2">
                  <strong className="text-white">{prescriptionHeader.doctorName}</strong>
                  <br />
                  {prescriptionHeader.qualification}
                  <br />
                  Reg. No: {prescriptionHeader.regNumber}
                </div>
                <div className="text-slate-400">{prescriptionHeader.address}</div>
                <div className="text-slate-400">
                  Phone: {prescriptionHeader.phone} | Email: {prescriptionHeader.email}
                </div>
              </div>

              <div className="bg-slate-700/50 p-4 rounded-lg mb-6 border border-slate-600">
                <strong className="text-white">Patient Information:</strong>
                <br />
                <span className="text-slate-300">Name: {prescription.patientName}</span>
                <br />
                <span className="text-slate-300">Age: {prescription.age}</span>
                <br />
                <span className="text-slate-300">
                  Date:{" "}
                  {new Date(prescription.date).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </span>
              </div>

              <div className="mb-6">
                <strong className="text-white">Diagnosis:</strong>{" "}
                <span className="text-slate-300">{prescription.diagnosis}</span>
                <br />
                <br />
                <strong className="text-white">Medications:</strong>
                <table className="w-full border-collapse mt-3">
                  <thead>
                    <tr>
                      <th className="border border-slate-600 p-2 text-left bg-slate-700 text-white">Medication</th>
                      <th className="border border-slate-600 p-2 text-left bg-slate-700 text-white">Dosage</th>
                      <th className="border border-slate-600 p-2 text-left bg-slate-700 text-white">Frequency</th>
                      <th className="border border-slate-600 p-2 text-left bg-slate-700 text-white">Duration</th>
                      <th className="border border-slate-600 p-2 text-left bg-slate-700 text-white">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {prescription.medications.map((med, index) => (
                      <tr key={index}>
                        <td className="border border-slate-600 p-2 text-slate-300">{med.name}</td>
                        <td className="border border-slate-600 p-2 text-slate-300">{med.dosage}</td>
                        <td className="border border-slate-600 p-2 text-slate-300">{med.frequency}</td>
                        <td className="border border-slate-600 p-2 text-slate-300">{med.duration}</td>
                        <td className="border border-slate-600 p-2 text-slate-300">{med.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <br />
                <strong className="text-white">Instructions:</strong>
                <br />
                <span className="text-slate-300 whitespace-pre-line">{prescription.instructions}</span>
                <br />
                <br />
                <strong className="text-white">Follow-up:</strong>{" "}
                <span className="text-slate-300">{prescription.followUp}</span>
              </div>

              <div className="mt-10 text-center text-slate-400 text-sm">
                <div className="border-t border-slate-600 w-48 mx-auto pt-2 text-white">
                  {prescriptionHeader.doctorName}
                </div>
                <p className="mt-2">This prescription is valid for 6 months from the date of issue.</p>
                <p>For any queries, please contact the clinic.</p>
              </div>
            </div>
          </Card>
        ) : (
          <div className="transition-all duration-300 ease-in-out">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Prescription Header Settings */}
              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <CardTitle className="text-white">Clinic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-2">
                    <Label className="text-slate-300">Clinic Name</Label>
                    <Input
                      value={prescriptionHeader.clinicName}
                      onChange={(e) => setPrescriptionHeader({ ...prescriptionHeader, clinicName: e.target.value })}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">Doctor Name</Label>
                    <Input
                      value={prescriptionHeader.doctorName}
                      onChange={(e) => setPrescriptionHeader({ ...prescriptionHeader, doctorName: e.target.value })}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">Qualification</Label>
                    <Input
                      value={prescriptionHeader.qualification}
                      onChange={(e) => setPrescriptionHeader({ ...prescriptionHeader, qualification: e.target.value })}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">Registration Number</Label>
                    <Input
                      value={prescriptionHeader.regNumber}
                      onChange={(e) => setPrescriptionHeader({ ...prescriptionHeader, regNumber: e.target.value })}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Patient Information */}
              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <CardTitle className="text-white">Patient Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-2">
                    <Label className="text-slate-300">Patient Name</Label>
                    <Input
                      value={prescription.patientName}
                      onChange={(e) => setPrescription({ ...prescription, patientName: e.target.value })}
                      placeholder="Enter patient name"
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">Age</Label>
                    <Input
                      type="number"
                      value={prescription.age}
                      onChange={(e) => setPrescription({ ...prescription, age: e.target.value })}
                      placeholder="Enter age"
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">Date</Label>
                    <Input
                      type="date"
                      value={prescription.date}
                      onChange={(e) => setPrescription({ ...prescription, date: e.target.value })}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">Diagnosis</Label>
                    <Textarea
                      value={prescription.diagnosis}
                      onChange={(e) => setPrescription({ ...prescription, diagnosis: e.target.value })}
                      placeholder="Enter diagnosis"
                      rows={3}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Medications */}
            <Card className="mt-6 bg-slate-800/80 border-slate-700">
              <CardHeader className="border-b border-slate-700 pb-4">
                <CardTitle className="flex items-center justify-between text-white">
                  <span className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-emerald-400" />
                    Medications
                  </span>
                  <Button
                    onClick={addMedication}
                    size="sm"
                    className="gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
                  >
                    <Plus className="h-4 w-4" />
                    Add Medication
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {prescription.medications.map((medication, index) => (
                    <div
                      key={index}
                      className="grid grid-cols-1 md:grid-cols-5 gap-4 p-4 border border-slate-600 rounded-lg bg-slate-700/50 transition-colors hover:bg-slate-700"
                    >
                      <div className="space-y-2">
                        <Label className="text-slate-300">Medication Name</Label>
                        <Select
                          value={medication.name}
                          onValueChange={(value) => updateMedication(index, "name", value)}
                        >
                          <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                            <SelectValue placeholder="Select medication" />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-800 border-slate-700">
                            {commonMedications.map((med) => (
                              <SelectItem key={med} value={med} className="text-white hover:bg-slate-700">
                                {med}
                              </SelectItem>
                            ))}
                            <SelectItem value="Other" className="text-white hover:bg-slate-700">
                              Other (specify)
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        {medication.name === "Other" && (
                          <Input
                            value={medication.name}
                            onChange={(e) => updateMedication(index, "name", e.target.value)}
                            placeholder="Enter medication name"
                            className="mt-2 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                          />
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label className="text-slate-300">Dosage</Label>
                        <Input
                          value={medication.dosage}
                          onChange={(e) => updateMedication(index, "dosage", e.target.value)}
                          placeholder="e.g., 500mg"
                          className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-slate-300">Frequency</Label>
                        <Input
                          value={medication.frequency}
                          onChange={(e) => updateMedication(index, "frequency", e.target.value)}
                          placeholder="e.g., Twice daily"
                          className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-slate-300">Duration</Label>
                        <Input
                          value={medication.duration}
                          onChange={(e) => updateMedication(index, "duration", e.target.value)}
                          placeholder="e.g., 7 days"
                          className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                        />
                      </div>
                      <div className="flex items-end gap-2">
                        <div className="space-y-2 flex-1">
                          <Label className="text-slate-300">Notes</Label>
                          <Input
                            value={medication.notes}
                            onChange={(e) => updateMedication(index, "notes", e.target.value)}
                            placeholder="Special instructions"
                            className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                          />
                        </div>
                        {prescription.medications.length > 1 && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-400 hover:text-red-300 hover:bg-slate-700"
                            onClick={() => removeMedication(index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Instructions and Follow-up */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <CardTitle className="text-white">Instructions</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <Textarea
                    value={prescription.instructions}
                    onChange={(e) => setPrescription({ ...prescription, instructions: e.target.value })}
                    placeholder="Enter special instructions for the patient..."
                    rows={6}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                  />
                </CardContent>
              </Card>

              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <CardTitle className="text-white">Follow-up</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <Textarea
                    value={prescription.followUp}
                    onChange={(e) => setPrescription({ ...prescription, followUp: e.target.value })}
                    placeholder="Enter follow-up instructions..."
                    rows={6}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                  />
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
