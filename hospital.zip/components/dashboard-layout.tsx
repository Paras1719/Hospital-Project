"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  Calendar,
  Users,
  FileText,
  History,
  Settings,
  LogOut,
  Menu,
  Stethoscope,
  Home,
  MessageSquare,
  ChevronDown,
  Bell,
  Plus,
  Search,
} from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"

const navigation = [
  {
    name: "Dashboard",
    href: "/dashboard",
    icon: Home,
    badge: null,
    description: "Overview & Analytics",
  },
  {
    name: "Schedule",
    href: "/dashboard/schedule",
    icon: Calendar,
    badge: 3,
    description: "Appointments & Time Slots",
  },
  {
    name: "Patients",
    href: "/dashboard/patients",
    icon: Users,
    badge: 12,
    description: "Patient Records",
  },
  {
    name: "Prescriptions",
    href: "/dashboard/prescriptions",
    icon: FileText,
    badge: 5,
    description: "Digital Prescriptions",
  },
  {
    name: "Patient History",
    href: "/dashboard/history",
    icon: History,
    badge: null,
    description: "Medical Records",
  },
  {
    name: "WhatsApp",
    href: "/dashboard/whatsapp",
    icon: MessageSquare,
    badge: 8,
    description: "Patient Communication",
  },
  {
    name: "Settings",
    href: "/dashboard/settings",
    icon: Settings,
    badge: null,
    description: "System Configuration",
  },
]

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [doctorId, setDoctorId] = useState("")
  const [doctorName, setDoctorName] = useState("")
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [hasUnreadNotifications, setHasUnreadNotifications] = useState(true)
  const [currentTime, setCurrentTime] = useState(new Date())
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    const storedDoctorId = localStorage.getItem("doctorId")
    const storedDoctorName = localStorage.getItem("doctorName") || "Smith"

    if (!storedDoctorId) {
      router.push("/")
    } else {
      setDoctorId(storedDoctorId)
      setDoctorName(storedDoctorName)
    }

    // Update time every minute
    const timer = setInterval(() => setCurrentTime(new Date()), 60000)
    return () => clearInterval(timer)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("doctorId")
    localStorage.removeItem("doctorName")
    router.push("/")
  }

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed)
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    })
  }

  const Sidebar = () => (
    <div className="flex flex-col h-full bg-gradient-to-b from-slate-900 to-slate-800">
      {/* Doctor Profile Header */}
      <div className="flex items-center gap-3 p-6 border-b border-slate-700 bg-gradient-to-r from-slate-800 to-slate-700">
        <Avatar className="h-12 w-12 ring-2 ring-emerald-500/50">
          <AvatarImage src={`/avatars/doctor-${doctorId}.jpg`} />
          <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-bold">
            {doctorName.charAt(0)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <Stethoscope className="h-4 w-4 text-emerald-400" />
            <h2 className="font-bold text-lg truncate bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              MediCare Pro
            </h2>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-sm text-slate-300 truncate">Dr. {doctorName}</p>
            <Badge
              variant="outline"
              className="text-xs px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
            >
              <div className="w-2 h-2 bg-emerald-400 rounded-full mr-1 animate-pulse"></div>
              Online
            </Badge>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 hidden lg:flex hover:bg-slate-700 text-slate-400"
          onClick={toggleSidebar}
        >
          <ChevronDown className={cn("h-4 w-4 transition-transform", isCollapsed && "rotate-90")} />
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="p-4 border-b border-slate-700 bg-slate-800/50">
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded-lg bg-slate-700/50 border border-slate-600">
            <div className="text-lg font-bold text-emerald-400">24</div>
            <div className="text-xs text-slate-400">Today</div>
          </div>
          <div className="p-2 rounded-lg bg-slate-700/50 border border-slate-600">
            <div className="text-lg font-bold text-teal-400">156</div>
            <div className="text-xs text-slate-400">This Week</div>
          </div>
          <div className="p-2 rounded-lg bg-slate-700/50 border border-slate-600">
            <div className="text-lg font-bold text-amber-400">98%</div>
            <div className="text-xs text-slate-400">Satisfaction</div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 overflow-y-auto">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const isActive = pathname === item.href
            return (
              <li key={item.name}>
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden",
                    isActive
                      ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg transform scale-[1.02]"
                      : "text-slate-300 hover:bg-slate-700/50 hover:text-emerald-400",
                    isCollapsed && "justify-center px-2",
                  )}
                >
                  {isActive && (
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 animate-pulse"></div>
                  )}
                  <div className="relative flex items-center gap-3">
                    <div
                      className={cn(
                        "p-1 rounded-lg transition-colors",
                        isActive ? "bg-white/20" : "group-hover:bg-emerald-500/20",
                      )}
                    >
                      <item.icon
                        className={cn(
                          "h-5 w-5 transition-colors",
                          isActive ? "text-white" : "text-slate-400 group-hover:text-emerald-400",
                        )}
                      />
                    </div>
                    {item.badge && (
                      <span
                        className={cn(
                          "absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center rounded-full text-xs font-medium",
                          isActive ? "bg-white text-emerald-600" : "bg-amber-500 text-white",
                        )}
                      >
                        {item.badge}
                      </span>
                    )}
                  </div>
                  {!isCollapsed && (
                    <div className="flex-1 min-w-0 relative">
                      <span className="font-medium">{item.name}</span>
                      <p className={cn("text-xs mt-0.5 truncate", isActive ? "text-emerald-100" : "text-slate-500")}>
                        {item.description}
                      </p>
                    </div>
                  )}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-slate-700 bg-slate-800/50">
        <div className="text-center mb-3">
          <p className="text-xs text-slate-500">Current Time</p>
          <p className="text-sm font-medium text-slate-300">{formatTime(currentTime)}</p>
        </div>
        <Button
          onClick={handleLogout}
          variant="outline"
          className={cn(
            "w-full flex items-center gap-2 border-slate-600 text-slate-300 hover:bg-red-500/20 hover:text-red-400 hover:border-red-500/50 transition-all duration-200",
            isCollapsed && "justify-center",
          )}
        >
          <LogOut className="h-4 w-4" />
          {!isCollapsed && "Sign Out"}
        </Button>
      </div>
    </div>
  )

  const currentPage = navigation.find((item) => item.href === pathname)

  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      {/* Desktop Sidebar */}
      <div
        className={cn(
          "hidden lg:flex flex-col bg-slate-900 border-r border-slate-700 shadow-xl transition-all duration-300 ease-in-out",
          isCollapsed ? "w-20" : "w-80",
        )}
      >
        <Sidebar />
      </div>

      {/* Mobile Sidebar */}
      <Sheet>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="lg:hidden fixed top-4 left-4 z-50 bg-slate-800 border-slate-700 text-slate-300 shadow-lg"
          >
            <Menu className="h-4 w-4" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-80 p-0 bg-slate-900 border-slate-700">
          <Sidebar />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="bg-slate-800/80 backdrop-blur-sm border-b border-slate-700 h-16 flex items-center justify-between px-6 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              {currentPage?.icon && (
                <div className="p-2 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg">
                  <currentPage.icon className="h-5 w-5 text-white" />
                </div>
              )}
              <div>
                <h1 className="text-xl font-bold text-white">{currentPage?.name || "Dashboard"}</h1>
                <p className="text-sm text-slate-400">{currentPage?.description || "Welcome back!"}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Quick search..."
                  className="pl-10 w-64 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500 transition-colors"
                />
              </div>
            </div>

            <Button variant="ghost" size="icon" className="relative hover:bg-slate-700 text-slate-400">
              <Bell className="h-5 w-5" />
              {hasUnreadNotifications && (
                <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
              )}
            </Button>

            <Button className="hidden sm:flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700">
              <Plus className="h-4 w-4" />
              New Appointment
            </Button>

            <Avatar className="h-9 w-9 cursor-pointer ring-2 ring-emerald-500/50 hover:ring-emerald-500/70 transition-all">
              <AvatarImage src={`/avatars/doctor-${doctorId}.jpg`} />
              <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                {doctorName.charAt(0)}
              </AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto bg-gradient-to-br from-slate-900/50 to-slate-800/50">
          <div className="p-6">
            <div className="max-w-7xl mx-auto">{children}</div>
          </div>
        </main>
      </div>
    </div>
  )
}
