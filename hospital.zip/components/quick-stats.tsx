import { Card, CardContent } from "@/components/ui/card"
import { Users, Calendar, FileText, ArrowUp, ArrowDown, TrendingUp, Heart, Activity } from "lucide-react"
import { cn } from "@/lib/utils"

const stats = [
  {
    title: "Total Patients",
    value: "1,234",
    change: "+12%",
    trend: "up",
    icon: Users,
    color: "text-emerald-400",
    bgColor: "bg-gradient-to-br from-emerald-500/20 to-emerald-600/20",
    borderColor: "border-emerald-500/30",
    description: "Active patients this month",
  },
  {
    title: "Today's Appointments",
    value: "12",
    change: "2 pending",
    trend: "neutral",
    icon: Calendar,
    color: "text-teal-400",
    bgColor: "bg-gradient-to-br from-teal-500/20 to-teal-600/20",
    borderColor: "border-teal-500/30",
    description: "Scheduled for today",
  },
  {
    title: "Prescriptions",
    value: "45",
    change: "+8%",
    trend: "up",
    icon: FileText,
    color: "text-cyan-400",
    bgColor: "bg-gradient-to-br from-cyan-500/20 to-cyan-600/20",
    borderColor: "border-cyan-500/30",
    description: "Issued this week",
  },
  {
    title: "Patient Satisfaction",
    value: "98%",
    change: "+2%",
    trend: "up",
    icon: Heart,
    color: "text-amber-400",
    bgColor: "bg-gradient-to-br from-amber-500/20 to-amber-600/20",
    borderColor: "border-amber-500/30",
    description: "Average rating",
  },
]

export default function QuickStats() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <div key={index} className="group">
          <Card
            className={cn(
              "border-2 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-2xl hover:scale-[1.02] cursor-pointer",
              stat.borderColor,
              "bg-slate-800/80 backdrop-blur-sm",
            )}
          >
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-400 mb-1">{stat.title}</p>
                  <h3 className="text-3xl font-bold tracking-tight text-white mb-1">{stat.value}</h3>
                  <p className="text-xs text-slate-500">{stat.description}</p>
                </div>
                <div
                  className={cn(
                    "p-3 rounded-xl transition-all duration-300 group-hover:scale-110 border",
                    stat.bgColor,
                    stat.borderColor,
                  )}
                >
                  <stat.icon className={cn("h-6 w-6", stat.color)} />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div
                  className={cn(
                    "flex items-center text-sm font-medium",
                    stat.trend === "up"
                      ? "text-emerald-400"
                      : stat.trend === "down"
                        ? "text-red-400"
                        : "text-slate-400",
                  )}
                >
                  {stat.trend === "up" && <ArrowUp className="h-4 w-4 mr-1" />}
                  {stat.trend === "down" && <ArrowDown className="h-4 w-4 mr-1" />}
                  {stat.trend === "neutral" && <Activity className="h-4 w-4 mr-1" />}
                  <span>{stat.change}</span>
                </div>

                {stat.trend === "up" && (
                  <div className="flex items-center text-xs text-emerald-400 bg-emerald-500/20 px-2 py-1 rounded-full border border-emerald-500/30">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    Trending
                  </div>
                )}
              </div>

              {/* Progress bar for visual appeal */}
              <div className="mt-4 w-full bg-slate-700 rounded-full h-1.5">
                <div
                  className={cn("h-1.5 rounded-full transition-all duration-1000", stat.color.replace("text-", "bg-"))}
                  style={{
                    width: stat.title.includes("Satisfaction")
                      ? "98%"
                      : stat.title.includes("Total")
                        ? "85%"
                        : stat.title.includes("Today")
                          ? "60%"
                          : "75%",
                  }}
                ></div>
              </div>
            </CardContent>
          </Card>
        </div>
      ))}
    </div>
  )
}
