"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Stethoscope, Eye, EyeOff, Heart, Shield, Users, Activity, Zap } from "lucide-react"

export default function LoginForm() {
  const [showPassword, setShowPassword] = useState(false)
  const [doctorId, setDoctorId] = useState("")
  const [password, setPassword] = useState("")
  const [showForgotPassword, setShowForgotPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate loading
    await new Promise((resolve) => setTimeout(resolve, 1500))

    if (doctorId && password) {
      localStorage.setItem("doctorId", doctorId)
      localStorage.setItem("doctorName", doctorId.replace(/[^a-zA-Z]/g, "") || "Smith")
      router.push("/dashboard")
    }
    setIsLoading(false)
  }

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault()
    alert("Password reset instructions sent to your registered email! 📧")
    setShowForgotPassword(false)
  }

  if (showForgotPassword) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-slate-800 flex items-center justify-center p-4">
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%2334d399' fillOpacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
              backgroundSize: "60px 60px",
            }}
          ></div>
        </div>

        <Card className="w-full max-w-md relative backdrop-blur-xl bg-slate-800/90 shadow-2xl border border-slate-700">
          <CardHeader className="text-center pb-2">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="p-4 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg">
                  <Stethoscope className="h-8 w-8 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 rounded-full animate-pulse"></div>
              </div>
            </div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              Reset Your Password
            </CardTitle>
            <CardDescription className="text-slate-400 mt-2">
              Don't worry! It happens to the best of us. Enter your Doctor ID below.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleForgotPassword} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="reset-doctor-id" className="text-sm font-medium text-slate-300">
                  Doctor ID
                </Label>
                <Input
                  id="reset-doctor-id"
                  type="text"
                  placeholder="Enter your Doctor ID"
                  required
                  className="h-12 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500 transition-colors"
                />
              </div>
              <div className="space-y-3">
                <Button
                  type="submit"
                  className="w-full h-12 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-medium rounded-xl transition-all duration-200 transform hover:scale-[1.02]"
                >
                  Send Reset Instructions 📧
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full h-12 border-slate-600 text-slate-300 hover:bg-slate-700 rounded-xl transition-all duration-200 bg-transparent"
                  onClick={() => setShowForgotPassword(false)}
                >
                  ← Back to Login
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-slate-800 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Graphics */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%2334d399' fillOpacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: "60px 60px",
          }}
        ></div>
      </div>

      {/* Floating Elements */}
      <div
        className="absolute top-20 left-20 w-20 h-20 bg-emerald-500/20 rounded-full opacity-30 animate-bounce"
        style={{ animationDelay: "0s", animationDuration: "3s" }}
      ></div>
      <div
        className="absolute top-40 right-32 w-16 h-16 bg-teal-500/20 rounded-full opacity-30 animate-bounce"
        style={{ animationDelay: "1s", animationDuration: "4s" }}
      ></div>
      <div
        className="absolute bottom-32 left-32 w-12 h-12 bg-amber-500/20 rounded-full opacity-30 animate-bounce"
        style={{ animationDelay: "2s", animationDuration: "5s" }}
      ></div>

      <div className="flex w-full max-w-6xl mx-auto items-center gap-12">
        {/* Left Side - Branding */}
        <div className="hidden lg:flex flex-1 flex-col items-center text-center space-y-8">
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-emerald-500 via-teal-600 to-cyan-500 rounded-3xl flex items-center justify-center shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-300">
              <Stethoscope className="h-16 w-16 text-white" />
            </div>
            <div className="absolute -top-2 -right-2 w-8 h-8 bg-amber-400 rounded-full flex items-center justify-center">
              <Heart className="h-4 w-4 text-white animate-pulse" />
            </div>
          </div>

          <div className="space-y-4">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent">
              MediCare Pro
            </h1>
            <p className="text-xl text-slate-300 max-w-md">Advanced Healthcare Management Platform</p>
            <p className="text-slate-400 max-w-lg leading-relaxed">
              Experience the future of medical practice management. Streamlined workflows, intelligent automation, and
              patient-centered care - all in one powerful platform.
            </p>
          </div>

          {/* Feature Icons */}
          <div className="flex gap-6 mt-8">
            <div className="flex flex-col items-center space-y-2 group">
              <div className="p-3 bg-emerald-500/20 rounded-xl group-hover:bg-emerald-500/30 transition-colors border border-emerald-500/30">
                <Users className="h-6 w-6 text-emerald-400" />
              </div>
              <span className="text-sm text-slate-400">Patient Care</span>
            </div>
            <div className="flex flex-col items-center space-y-2 group">
              <div className="p-3 bg-teal-500/20 rounded-xl group-hover:bg-teal-500/30 transition-colors border border-teal-500/30">
                <Activity className="h-6 w-6 text-teal-400" />
              </div>
              <span className="text-sm text-slate-400">Analytics</span>
            </div>
            <div className="flex flex-col items-center space-y-2 group">
              <div className="p-3 bg-amber-500/20 rounded-xl group-hover:bg-amber-500/30 transition-colors border border-amber-500/30">
                <Shield className="h-6 w-6 text-amber-400" />
              </div>
              <span className="text-sm text-slate-400">Secure</span>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="flex-1 max-w-md">
          <Card className="relative backdrop-blur-xl bg-slate-800/90 shadow-2xl border border-slate-700 overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500"></div>

            <CardHeader className="text-center pb-6">
              <div className="flex justify-center mb-6 lg:hidden">
                <div className="relative">
                  <div className="p-4 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg">
                    <Stethoscope className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 rounded-full animate-pulse"></div>
                </div>
              </div>
              <CardTitle className="text-2xl font-bold text-white">Welcome Back, Doctor! 👋</CardTitle>
              <CardDescription className="text-slate-400 mt-2">
                Access your advanced practice dashboard and continue delivering exceptional healthcare.
              </CardDescription>
            </CardHeader>

            <CardContent>
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="doctor-id" className="text-sm font-medium text-slate-300">
                    Doctor ID
                  </Label>
                  <Input
                    id="doctor-id"
                    type="text"
                    placeholder="Enter your unique Doctor ID"
                    value={doctorId}
                    onChange={(e) => setDoctorId(e.target.value)}
                    required
                    className="h-12 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500 transition-colors rounded-xl"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium text-slate-300">
                    Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your secure password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="h-12 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500 transition-colors rounded-xl pr-12"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent text-slate-400 hover:text-slate-300"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-medium rounded-xl transition-all duration-200 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Signing you in...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4" />
                      Access Dashboard
                    </div>
                  )}
                </Button>

                <div className="text-center">
                  <Button
                    type="button"
                    variant="link"
                    className="text-sm text-emerald-400 hover:text-emerald-300 transition-colors"
                    onClick={() => setShowForgotPassword(true)}
                  >
                    Forgot your password? Reset it here 🔐
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Trust Indicators */}
          <div className="mt-6 text-center space-y-2">
            <p className="text-xs text-slate-500">Trusted by 10,000+ healthcare professionals worldwide</p>
            <div className="flex justify-center gap-4 text-xs text-slate-400">
              <span className="flex items-center gap-1">
                <Shield className="h-3 w-3" />
                HIPAA Compliant
              </span>
              <span className="flex items-center gap-1">
                <Heart className="h-3 w-3" />
                99.9% Uptime
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
