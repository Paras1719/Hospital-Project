"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Users, Search, Plus, Eye, Edit, Calendar, X, ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Skeleton } from "@/components/ui/skeleton"

// Define types for better data structure and clarity
interface Patient {
  id: number
  name: string
  age: number
  phone: string
  lastVisit: string
  condition: string
  status: "New" | "Regular" | "Follow-up" | "Critical"
  visitCount: number
  gender: string
  avatar?: string
}

const statusOptions = [
  { value: "New", label: "New", color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
  { value: "Regular", label: "Regular", color: "bg-teal-500/20 text-teal-400 border-teal-500/30" },
  { value: "Follow-up", label: "Follow-up", color: "bg-amber-500/20 text-amber-400 border-amber-500/30" },
  { value: "Critical", label: "Critical", color: "bg-red-500/20 text-red-400 border-red-500/30" },
]

const initialPatients: Patient[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    age: 34,
    phone: "+1 (555) 123-4567",
    lastVisit: "2024-01-15",
    condition: "Hypertension",
    status: "Regular",
    visitCount: 3,
    gender: "Female",
    avatar: "/avatars/patient-1.jpg",
  },
  {
    id: 2,
    name: "Michael Brown",
    age: 45,
    phone: "+1 (555) 234-5678",
    lastVisit: "2024-01-14",
    condition: "Diabetes Type 2",
    status: "Follow-up",
    visitCount: 5,
    gender: "Male",
    avatar: "/avatars/patient-2.jpg",
  },
  {
    id: 3,
    name: "Emily Davis",
    age: 28,
    phone: "+1 (555) 345-6789",
    lastVisit: "2024-01-13",
    condition: "Migraine",
    status: "New",
    visitCount: 1,
    gender: "Female",
    avatar: "/avatars/patient-3.jpg",
  },
  {
    id: 4,
    name: "Robert Wilson",
    age: 52,
    phone: "+1 (555) 456-7890",
    lastVisit: "2024-01-12",
    condition: "Heart Disease",
    status: "Critical",
    visitCount: 8,
    gender: "Male",
    avatar: "/avatars/patient-4.jpg",
  },
  {
    id: 5,
    name: "Lisa Anderson",
    age: 38,
    phone: "+1 (555) 567-8901",
    lastVisit: "2024-01-11",
    condition: "Anxiety",
    status: "Regular",
    visitCount: 4,
    gender: "Female",
    avatar: "/avatars/patient-5.jpg",
  },
]

export default function PatientManager() {
  const [patients, setPatients] = useState<Patient[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [isAddingPatient, setIsAddingPatient] = useState(false)
  const [expandedPatient, setExpandedPatient] = useState<number | null>(null)
  const [newPatient, setNewPatient] = useState({
    name: "",
    age: "",
    phone: "",
    condition: "",
    status: "New",
    gender: "Female",
  })
  const [isLoading, setIsLoading] = useState(true) // State for loading data

  // Simulate fetching data from backend
  useEffect(() => {
    setIsLoading(true)
    // In a real application, you would fetch data here:
    // fetch('/api/patients').then(res => res.json()).then(data => {
    //   setPatients(data);
    //   setIsLoading(false);
    // });
    const timer = setTimeout(() => {
      setPatients(initialPatients)
      setIsLoading(false)
    }, 1000) // Simulate network delay
    return () => clearTimeout(timer)
  }, [])

  const filteredPatients = patients.filter((patient) => {
    const matchesSearch =
      patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.condition.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.phone.includes(searchTerm)
    const matchesFilter = filterStatus === "all" || patient.status === filterStatus
    return matchesSearch && matchesFilter
  })

  const addPatient = () => {
    if (newPatient.name && newPatient.age && newPatient.phone) {
      const patient: Patient = {
        id: Date.now(), // Unique ID for demo
        ...newPatient,
        age: Number(newPatient.age),
        lastVisit: new Date().toISOString().split("T")[0],
        visitCount: 1,
        avatar: `/avatars/patient-${Math.floor(Math.random() * 5) + 1}.jpg`, // Random avatar for new patient
      }
      setPatients([...patients, patient])
      setNewPatient({
        name: "",
        age: "",
        phone: "",
        condition: "",
        status: "New",
        gender: "Female",
      })
      setIsAddingPatient(false)
      // In a real application, you would send this data to your backend:
      // await fetch('/api/patients', { method: 'POST', body: JSON.stringify(patient) });
    }
  }

  const togglePatientExpand = (id: number) => {
    setExpandedPatient(expandedPatient === id ? null : id)
  }

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: "numeric", month: "short", day: "numeric" }
    return new Date(dateString).toLocaleDateString("en-US", options)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Patient Records</h1>
          <p className="text-slate-400">Manage your patient database</p>
        </div>
        <Button
          onClick={() => setIsAddingPatient(true)}
          className="gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
        >
          <Plus className="h-4 w-4" />
          Add Patient
        </Button>
      </div>

      {isAddingPatient && (
        <div className="transition-all duration-300 ease-in-out overflow-hidden">
          <Card className="mb-6 bg-slate-800/80 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between border-b border-slate-700 pb-4">
              <CardTitle className="text-white">Add New Patient</CardTitle>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsAddingPatient(false)}
                className="text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-slate-300">Full Name</Label>
                  <Input
                    value={newPatient.name}
                    onChange={(e) => setNewPatient({ ...newPatient, name: e.target.value })}
                    placeholder="Patient name"
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">Age</Label>
                  <Input
                    type="number"
                    value={newPatient.age}
                    onChange={(e) => setNewPatient({ ...newPatient, age: e.target.value })}
                    placeholder="Age"
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">Phone</Label>
                  <Input
                    value={newPatient.phone}
                    onChange={(e) => setNewPatient({ ...newPatient, phone: e.target.value })}
                    placeholder="Phone number"
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">Condition</Label>
                  <Input
                    value={newPatient.condition}
                    onChange={(e) => setNewPatient({ ...newPatient, condition: e.target.value })}
                    placeholder="Medical condition"
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">Gender</Label>
                  <Select
                    value={newPatient.gender}
                    onValueChange={(value) => setNewPatient({ ...newPatient, gender: value })}
                  >
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      <SelectItem value="Female" className="text-white hover:bg-slate-700">
                        Female
                      </SelectItem>
                      <SelectItem value="Male" className="text-white hover:bg-slate-700">
                        Male
                      </SelectItem>
                      <SelectItem value="Other" className="text-white hover:bg-slate-700">
                        Other
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">Status</Label>
                  <Select
                    value={newPatient.status}
                    onValueChange={(value) => setNewPatient({ ...newPatient, status: value as Patient["status"] })}
                  >
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      {statusOptions.map((status) => (
                        <SelectItem key={status.value} value={status.value} className="text-white hover:bg-slate-700">
                          {status.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex gap-2 mt-6">
                <Button
                  onClick={addPatient}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
                >
                  Add Patient
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setIsAddingPatient(false)}
                  className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Card className="bg-slate-800/80 border-slate-700">
        <CardHeader className="border-b border-slate-700 pb-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle className="flex items-center gap-2 text-white">
              <Users className="h-5 w-5 text-emerald-400" />
              Patient Records
            </CardTitle>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search patients..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[180px] bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="all" className="text-white hover:bg-slate-700">
                    All Patients
                  </SelectItem>
                  {statusOptions.map((status) => (
                    <SelectItem key={status.value} value={status.value} className="text-white hover:bg-slate-700">
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-2">
            {isLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-4 p-4 border border-slate-700 rounded-lg bg-slate-700/50"
                  >
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-3 w-1/2" />
                    </div>
                    <Skeleton className="h-8 w-8 rounded-full" />
                  </div>
                ))}
              </div>
            ) : filteredPatients.length === 0 ? (
              <div className="py-8 text-center text-slate-400">No patients found matching your criteria</div>
            ) : (
              filteredPatients.map((patient) => (
                <div
                  key={patient.id}
                  className={cn(
                    "overflow-hidden transition-all duration-200 hover:shadow-sm",
                    expandedPatient === patient.id && "border-emerald-500",
                  )}
                >
                  <Card
                    className={cn(
                      "bg-slate-700/50 border-slate-600 hover:bg-slate-700 transition-colors",
                      expandedPatient === patient.id && "bg-slate-700 border-emerald-500/50",
                    )}
                  >
                    <div
                      className="flex items-center justify-between p-4 cursor-pointer"
                      onClick={() => togglePatientExpand(patient.id)}
                    >
                      <div className="flex items-center gap-4">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={patient.avatar || "/placeholder.svg"} />
                          <AvatarFallback className="bg-emerald-500/20 text-emerald-400">
                            {patient.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-white">{patient.name}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge
                              variant="outline"
                              className={cn("text-xs", statusOptions.find((s) => s.value === patient.status)?.color)}
                            >
                              {patient.status}
                            </Badge>
                            <span className="text-sm text-slate-400">
                              {patient.gender}, {patient.age} years
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-400 hover:text-white">
                          {expandedPatient === patient.id ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                    {expandedPatient === patient.id && (
                      <div className="border-t border-slate-600 p-4 transition-all duration-200 ease-in-out">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          <div className="space-y-1">
                            <p className="text-sm text-slate-400">Condition</p>
                            <p className="font-medium text-slate-300">{patient.condition}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm text-slate-400">Phone</p>
                            <p className="font-medium text-slate-300">{patient.phone}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm text-slate-400">Last Visit</p>
                            <p className="font-medium text-slate-300">{formatDate(patient.lastVisit)}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm text-slate-400">Total Visits</p>
                            <p className="font-medium text-slate-300">{patient.visitCount}</p>
                          </div>
                        </div>
                        <div className="flex justify-end gap-2 mt-4">
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2 border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                          >
                            <Calendar className="h-4 w-4" />
                            Schedule
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2 border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                          >
                            <Edit className="h-4 w-4" />
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            className="gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
                          >
                            <Eye className="h-4 w-4" />
                            View Profile
                          </Button>
                        </div>
                      </div>
                    )}
                  </Card>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
