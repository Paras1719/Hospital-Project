"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Plus, Trash2, ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"
import { Skeleton } from "@/components/ui/skeleton"

// Define types for better data structure
interface TimeSlot {
  id: number
  startTime: string
  endTime: string
  type: string
}

interface Schedule {
  [key: string]: TimeSlot[]
}

const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

const appointmentTypes = [
  { value: "Consultation", label: "Consultation", color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
  { value: "Follow-up", label: "Follow-up", color: "bg-teal-500/20 text-teal-400 border-teal-500/30" },
  { value: "Surgery", label: "Surgery", color: "bg-red-500/20 text-red-400 border-red-500/30" },
  { value: "Emergency", label: "Emergency", color: "bg-amber-500/20 text-amber-400 border-amber-500/30" },
  { value: "Checkup", label: "Checkup", color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
]

const initialSchedule: Schedule = {
  Monday: [
    { id: 1, startTime: "09:00", endTime: "12:00", type: "Consultation" },
    { id: 2, startTime: "14:00", endTime: "17:00", type: "Follow-up" },
  ],
  Tuesday: [{ id: 3, startTime: "10:00", endTime: "13:00", type: "Consultation" }],
  Wednesday: [
    { id: 4, startTime: "09:00", endTime: "12:00", type: "Surgery" },
    { id: 5, startTime: "15:00", endTime: "18:00", type: "Consultation" },
  ],
  Thursday: [{ id: 6, startTime: "08:00", endTime: "11:00", type: "Emergency" }],
  Friday: [{ id: 7, startTime: "09:00", endTime: "16:00", type: "Consultation" }],
  Saturday: [{ id: 8, startTime: "10:00", endTime: "14:00", type: "Consultation" }],
  Sunday: [],
}

export default function ScheduleManager() {
  const [schedule, setSchedule] = useState<Schedule>({})
  const [isAddingSlot, setIsAddingSlot] = useState(false)
  const [selectedDay, setSelectedDay] = useState("")
  const [newSlot, setNewSlot] = useState({
    startTime: "",
    endTime: "",
    type: "Consultation",
  })
  const [expandedDays, setExpandedDays] = useState<Record<string, boolean>>(
    daysOfWeek.reduce((acc, day) => ({ ...acc, [day]: true }), {}),
  )
  const [isLoading, setIsLoading] = useState(true)

  // Simulate fetching schedule data from backend
  useEffect(() => {
    setIsLoading(true)
    // In a real application, you would fetch data here:
    // fetch('/api/schedule').then(res => res.json()).then(data => {
    //   setSchedule(data);
    //   setIsLoading(false);
    // });
    const timer = setTimeout(() => {
      setSchedule(initialSchedule)
      setIsLoading(false)
    }, 1000) // Simulate network delay
    return () => clearTimeout(timer)
  }, [])

  const toggleDay = (day: string) => {
    setExpandedDays((prev) => ({ ...prev, [day]: !prev[day] }))
  }

  const addTimeSlot = () => {
    if (selectedDay && newSlot.startTime && newSlot.endTime) {
      const newId = Date.now()
      const updatedSchedule = {
        ...schedule,
        [selectedDay]: [...schedule[selectedDay], { ...newSlot, id: newId }],
      }
      setSchedule(updatedSchedule)
      setNewSlot({ startTime: "", endTime: "", type: "Consultation" })
      setIsAddingSlot(false)
      setSelectedDay("")
      // In a real application, you would send this data to your backend:
      // await fetch('/api/schedule', { method: 'POST', body: JSON.stringify(newSlot) });
    }
  }

  const removeTimeSlot = (day: string, slotId: number) => {
    const updatedSchedule = {
      ...schedule,
      [day]: schedule[day].filter((slot) => slot.id !== slotId),
    }
    setSchedule(updatedSchedule)
    // In a real application, you would send this deletion request to your backend:
    // await fetch(`/api/schedule/${slotId}`, { method: 'DELETE' });
  }

  const getTypeColor = (type: string) => {
    return appointmentTypes.find((t) => t.value === type)?.color || "bg-slate-600/50 text-slate-300 border-slate-500"
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Schedule Management</h1>
          <p className="text-slate-400">Manage your weekly appointment schedule</p>
        </div>
        <Button
          onClick={() => setIsAddingSlot(true)}
          className="gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
        >
          <Plus className="h-4 w-4" />
          Add Time Slot
        </Button>
      </div>

      {isAddingSlot && (
        <div className="transition-all duration-300 ease-in-out overflow-hidden">
          <Card className="mb-6 bg-slate-800/80 border-slate-700">
            <CardHeader className="border-b border-slate-700 pb-4">
              <CardTitle className="text-white">Add New Time Slot</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label className="text-slate-300">Day</Label>
                  <Select value={selectedDay} onValueChange={setSelectedDay}>
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                      <SelectValue placeholder="Select day" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      {daysOfWeek.map((day) => (
                        <SelectItem key={day} value={day} className="text-white hover:bg-slate-700">
                          {day}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">Start Time</Label>
                  <Input
                    type="time"
                    value={newSlot.startTime}
                    onChange={(e) => setNewSlot({ ...newSlot, startTime: e.target.value })}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">End Time</Label>
                  <Input
                    type="time"
                    value={newSlot.endTime}
                    onChange={(e) => setNewSlot({ ...newSlot, endTime: e.target.value })}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">Type</Label>
                  <Select value={newSlot.type} onValueChange={(value) => setNewSlot({ ...newSlot, type: value })}>
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      {appointmentTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value} className="text-white hover:bg-slate-700">
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button
                  onClick={addTimeSlot}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
                >
                  Add Slot
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddingSlot(false)
                    setNewSlot({ startTime: "", endTime: "", type: "Consultation" })
                  }}
                  className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4">
        {isLoading
          ? Array.from({ length: 3 }).map((_, i) => (
              <Card key={i} className="bg-slate-800/80 border-slate-700">
                <CardHeader className="border-b border-slate-700 pb-4">
                  <Skeleton className="h-6 w-1/3" />
                </CardHeader>
                <CardContent className="pt-6 space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg border border-slate-700 bg-slate-700/50">
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <div className="space-y-1">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-3 w-16" />
                      </div>
                    </div>
                    <Skeleton className="h-8 w-8 rounded-full" />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg border border-slate-700 bg-slate-700/50">
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <div className="space-y-1">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-3 w-16" />
                      </div>
                    </div>
                    <Skeleton className="h-8 w-8 rounded-full" />
                  </div>
                </CardContent>
              </Card>
            ))
          : daysOfWeek.map((day) => (
              <Card key={day} className="overflow-hidden bg-slate-800/80 border-slate-700">
                <CardHeader
                  className={cn(
                    "cursor-pointer hover:bg-slate-700/50 transition-colors",
                    "flex items-center justify-between",
                    "border-b border-slate-700",
                  )}
                  onClick={() => toggleDay(day)}
                >
                  <CardTitle className="flex items-center gap-3 text-white">
                    <Calendar className="h-5 w-5 text-emerald-400" />
                    <span>{day}</span>
                    <Badge variant="secondary" className="ml-2 bg-slate-700/50 text-slate-300 border-slate-600">
                      {schedule[day]?.length || 0} slot{schedule[day]?.length !== 1 ? "s" : ""}
                    </Badge>
                  </CardTitle>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-white">
                    {expandedDays[day] ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>
                </CardHeader>
                {expandedDays[day] && (
                  <CardContent className="p-4 transition-all duration-200 ease-in-out">
                    {schedule[day]?.length === 0 ? (
                      <div className="py-6 text-center text-slate-400">No appointments scheduled</div>
                    ) : (
                      <div className="space-y-3">
                        {schedule[day].map((slot) => (
                          <div
                            key={slot.id}
                            className="flex items-center justify-between p-3 rounded-lg border border-slate-600 bg-slate-700/50 hover:bg-slate-700 transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                                <Clock className="h-4 w-4 text-emerald-400" />
                              </div>
                              <div>
                                <p className="font-medium text-white">
                                  {slot.startTime} - {slot.endTime}
                                </p>
                                <Badge className={cn("text-xs", getTypeColor(slot.type))}>{slot.type}</Badge>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-400 hover:text-red-300 hover:bg-slate-700"
                              onClick={() => removeTimeSlot(day, slot.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                )}
              </Card>
            ))}
      </div>
    </div>
  )
}
