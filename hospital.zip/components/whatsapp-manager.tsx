"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { MessageSquare, Send, Users, FileText, Bell, Check, ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Skeleton } from "@/components/ui/skeleton"

// Define types for better data structure
interface Patient {
  id: number
  name: string
  phone: string
  avatar?: string
}

interface MessageTemplate {
  id: string
  name: string
  content: string
}

const initialPatients: Patient[] = [
  { id: 1, name: "Sarah Johnson", phone: "+1234567890", avatar: "/avatars/patient-1.jpg" },
  { id: 2, name: "Michael Brown", phone: "+1234567891", avatar: "/avatars/patient-2.jpg" },
  { id: 3, name: "Emily Davis", phone: "+1234567892", avatar: "/avatars/patient-3.jpg" },
  { id: 4, name: "Robert Wilson", phone: "+1234567893", avatar: "/avatars/patient-4.jpg" },
]

const messageTemplates: MessageTemplate[] = [
  {
    id: "appointment-reminder",
    name: "Appointment Reminder",
    content:
      "Dear {name},\n\nThis is a reminder for your appointment on {date} at {time}.\n\nPlease arrive 15 minutes early.\n\nBest regards,\n{clinic}",
  },
  {
    id: "test-results",
    name: "Test Results Available",
    content:
      "Dear {name},\n\nYour test results are now available. Please contact our office to discuss them.\n\nBest regards,\n{clinic}",
  },
  {
    id: "prescription-ready",
    name: "Prescription Ready",
    content:
      "Dear {name},\n\nYour prescription is ready at {pharmacy}.\n\nMedications:\n- {medication1}\n- {medication2}\n\nBest regards,\n{clinic}",
  },
]

export default function WhatsAppManager() {
  const [messageType, setMessageType] = useState("announcement")
  const [selectedPatients, setSelectedPatients] = useState<number[]>([1])
  const [message, setMessage] = useState("")
  const [prescriptionMessage, setPrescriptionMessage] = useState({
    patientId: "1",
    medications: "Lisinopril 10mg, once daily\nAtorvastatin 20mg, at bedtime",
    instructions: "Take with food. Avoid alcohol. Follow up in 4 weeks.",
  })
  const [selectedTemplate, setSelectedTemplate] = useState("")
  const [expandedInfo, setExpandedInfo] = useState(true)
  const [patientsData, setPatientsData] = useState<Patient[]>([])
  const [isLoadingPatients, setIsLoadingPatients] = useState(true)

  // Simulate fetching patients data
  useEffect(() => {
    setIsLoadingPatients(true)
    // In a real application, fetch patients from your backend
    // fetch('/api/patients').then(res => res.json()).then(data => {
    //   setPatientsData(data);
    //   setIsLoadingPatients(false);
    // });
    const timer = setTimeout(() => {
      setPatientsData(initialPatients)
      setIsLoadingPatients(false)
    }, 800)
    return () => clearTimeout(timer)
  }, [])

  const handleSendAnnouncement = () => {
    if (selectedPatients.length > 0 && message) {
      // In a real application, you would send this message to a backend service
      // that integrates with WhatsApp Business API.
      // For demo, we open WhatsApp Web/App with pre-filled message.
      selectedPatients.forEach((patientId) => {
        const patient = patientsData.find((p) => p.id === patientId)
        if (patient) {
          const whatsappUrl = `https://wa.me/${patient.phone.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(message)}`
          window.open(whatsappUrl, "_blank")
        }
      })

      setMessage("")
      alert(`Announcement sent to ${selectedPatients.length} patient(s)! (Check new tabs)`)
    }
  }

  const handleSendPrescription = () => {
    if (prescriptionMessage.patientId && prescriptionMessage.medications) {
      const patient = patientsData.find((p) => p.id === Number.parseInt(prescriptionMessage.patientId))
      const whatsappMessage = `
*Prescription from Heart Care Clinic*

Dear ${patient?.name},

Your prescribed medications:
${prescriptionMessage.medications}

Instructions:
${prescriptionMessage.instructions}

Please follow the medication schedule as prescribed. Contact us if you have any questions.

Best regards,
Dr. John Smith
Heart Care Clinic
      `.trim()

      const whatsappUrl = `https://wa.me/${patient?.phone.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(whatsappMessage)}`
      window.open(whatsappUrl, "_blank")
      alert(`Prescription sent to ${patient?.name}! (Check new tab)`)
    }
  }

  const togglePatientSelection = (patientId: number) => {
    setSelectedPatients((prev) =>
      prev.includes(patientId) ? prev.filter((id) => id !== patientId) : [...prev, patientId],
    )
  }

  const selectAllPatients = () => {
    setSelectedPatients(patientsData.map((p) => p.id))
  }

  const clearSelection = () => {
    setSelectedPatients([])
  }

  const applyTemplate = () => {
    const template = messageTemplates.find((t) => t.id === selectedTemplate)
    if (template) {
      setMessage(
        template.content
          .replace("{name}", "Patient") // Placeholder for dynamic patient name
          .replace("{date}", new Date().toLocaleDateString())
          .replace("{time}", "10:00 AM")
          .replace("{clinic}", "Heart Care Clinic")
          .replace("{pharmacy}", "Main Street Pharmacy")
          .replace("{medication1}", "Medication 1")
          .replace("{medication2}", "Medication 2"),
      )
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">WhatsApp Communication</h1>
          <p className="text-slate-400">Manage patient communications via WhatsApp</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            Integration Settings
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Message Type Selection */}
        <Card className="bg-slate-800/80 border-slate-700">
          <CardHeader className="border-b border-slate-700 pb-4">
            <CardTitle className="text-white">Message Type</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-6">
            <Select value={messageType} onValueChange={setMessageType}>
              <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="announcement" className="text-white hover:bg-slate-700">
                  <div className="flex items-center gap-2">
                    <Bell className="h-4 w-4 text-emerald-400" />
                    Announcement
                  </div>
                </SelectItem>
                <SelectItem value="prescription" className="text-white hover:bg-slate-700">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-teal-400" />
                    Prescription
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>

            {messageType === "announcement" && (
              <div className="space-y-2 transition-all duration-200 ease-in-out">
                <Label className="text-slate-300">Templates</Label>
                <div className="flex gap-2">
                  <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      {messageTemplates.map((template) => (
                        <SelectItem key={template.id} value={template.id} className="text-white hover:bg-slate-700">
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    onClick={applyTemplate}
                    disabled={!selectedTemplate}
                    className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                  >
                    Apply
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Patient Selection */}
        <Card className="lg:col-span-2 bg-slate-800/80 border-slate-700">
          <CardHeader className="border-b border-slate-700 pb-4">
            <CardTitle className="flex items-center justify-between text-white">
              <span className="flex items-center gap-2">
                <Users className="h-5 w-5 text-emerald-400" />
                Patient Selection
                <Badge variant="secondary" className="ml-2 bg-slate-700/50 text-slate-300 border-slate-600">
                  {selectedPatients.length} selected
                </Badge>
              </span>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={selectAllPatients}
                  className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                >
                  Select All
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearSelection}
                  className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                >
                  Clear
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            {isLoadingPatients ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div
                    key={i}
                    className="p-3 border border-slate-700 rounded-lg bg-slate-700/50 flex items-center gap-3"
                  >
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-3 w-1/2" />
                    </div>
                    <Skeleton className="h-6 w-6 rounded-full" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {patientsData.map((patient) => (
                  <div
                    key={patient.id}
                    className={cn(
                      "p-3 border rounded-lg cursor-pointer transition-colors flex items-center gap-3",
                      selectedPatients.includes(patient.id)
                        ? "bg-emerald-500/20 border-emerald-500/30"
                        : "bg-slate-700/50 border-slate-600 hover:bg-slate-700",
                    )}
                    onClick={() => togglePatientSelection(patient.id)}
                  >
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={patient.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="bg-emerald-500/20 text-emerald-400">
                        {patient.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate text-white">{patient.name}</p>
                      <p className="text-sm text-slate-400 truncate">{patient.phone}</p>
                    </div>
                    {selectedPatients.includes(patient.id) && (
                      <div className="bg-emerald-100 p-1 rounded-full">
                        <Check className="h-4 w-4 text-emerald-800" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {messageType === "announcement" && (
        <div className="transition-all duration-300 ease-in-out overflow-hidden">
          <Card className="bg-slate-800/80 border-slate-700">
            <CardHeader className="border-b border-slate-700 pb-4">
              <CardTitle className="flex items-center gap-2 text-white">
                <Bell className="h-5 w-5 text-emerald-400" />
                Announcement Message
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div>
                <Label className="text-slate-300">Message Content</Label>
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Enter your announcement message..."
                  rows={8}
                  className="font-mono text-sm bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                />
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm text-slate-400">
                  Will be sent to {selectedPatients.length} patient{selectedPatients.length !== 1 ? "s" : ""}
                </p>
                <Button
                  onClick={handleSendAnnouncement}
                  disabled={selectedPatients.length === 0 || !message}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 gap-2"
                >
                  <Send className="h-4 w-4" />
                  Send to Selected
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {messageType === "prescription" && (
        <div className="transition-all duration-300 ease-in-out overflow-hidden">
          <Card className="bg-slate-800/80 border-slate-700">
            <CardHeader className="border-b border-slate-700 pb-4">
              <CardTitle className="flex items-center gap-2 text-white">
                <FileText className="h-5 w-5 text-teal-400" />
                Prescription Message
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div>
                <Label className="text-slate-300">Select Patient</Label>
                <Select
                  value={prescriptionMessage.patientId}
                  onValueChange={(value) => setPrescriptionMessage({ ...prescriptionMessage, patientId: value })}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                    <SelectValue placeholder="Choose a patient" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {patientsData.map((patient) => (
                      <SelectItem
                        key={patient.id}
                        value={patient.id.toString()}
                        className="text-white hover:bg-slate-700"
                      >
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={patient.avatar || "/placeholder.svg"} />
                            <AvatarFallback className="text-xs bg-emerald-500/20 text-emerald-400">
                              {patient.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          {patient.name} - {patient.phone}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-slate-300">Medications</Label>
                <Textarea
                  value={prescriptionMessage.medications}
                  onChange={(e) => setPrescriptionMessage({ ...prescriptionMessage, medications: e.target.value })}
                  placeholder="Enter prescribed medications (one per line)..."
                  rows={4}
                  className="font-mono text-sm bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                />
              </div>
              <div>
                <Label className="text-slate-300">Instructions</Label>
                <Textarea
                  value={prescriptionMessage.instructions}
                  onChange={(e) => setPrescriptionMessage({ ...prescriptionMessage, instructions: e.target.value })}
                  placeholder="Enter special instructions..."
                  rows={4}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                />
              </div>
              <div className="flex justify-end">
                <Button
                  onClick={handleSendPrescription}
                  disabled={!prescriptionMessage.patientId || !prescriptionMessage.medications}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 gap-2"
                >
                  <Send className="h-4 w-4" />
                  Send via WhatsApp
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Help Card */}
      <Card className="bg-slate-800/80 border-slate-700">
        <CardHeader
          className="cursor-pointer border-b border-slate-700 pb-4"
          onClick={() => setExpandedInfo(!expandedInfo)}
        >
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">WhatsApp Integration Guide</CardTitle>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-white">
              {expandedInfo ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </Button>
          </div>
        </CardHeader>
        {expandedInfo && (
          <div className="transition-all duration-200 ease-in-out overflow-hidden">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                  <h4 className="font-semibold text-emerald-400 mb-2">Features:</h4>
                  <ul className="text-sm text-slate-300 space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="mt-1">•</span>
                      <span>
                        <strong>Announcements:</strong> Send to multiple patients simultaneously with consistent
                        formatting
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1">•</span>
                      <span>
                        <strong>Prescriptions:</strong> Professionally formatted with medications and instructions
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="mt-1">•</span>
                      <span>
                        <strong>Templates:</strong> Save time with pre-written message templates
                      </span>
                    </li>
                  </ul>
                </div>
                <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                  <h4 className="font-semibold text-amber-400 mb-2">Implementation Note:</h4>
                  <p className="text-sm text-slate-300">
                    For full automation, connect to the WhatsApp Business API. Currently this opens WhatsApp with
                    pre-filled messages that need to be manually sent.
                  </p>
                </div>
              </div>
            </CardContent>
          </div>
        )}
      </Card>
    </div>
  )
}
