import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { User, Eye } from "lucide-react"

const recentPatients = [
  {
    id: 1,
    name: "Alice Cooper",
    lastVisit: "2024-01-15",
    condition: "Hypertension",
    age: 45,
  },
  {
    id: 2,
    name: "David Miller",
    lastVisit: "2024-01-14",
    condition: "Diabetes",
    age: 52,
  },
  {
    id: 3,
    name: "Lisa Anderson",
    lastVisit: "2024-01-13",
    condition: "Chest Pain",
    age: 38,
  },
  {
    id: 4,
    name: "James Taylor",
    lastVisit: "2024-01-12",
    condition: "Regular Checkup",
    age: 29,
  },
]

export default function RecentPatients() {
  return (
    <Card className="bg-slate-800/80 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <User className="h-5 w-5 text-teal-400" />
          Recent Patients
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentPatients.map((patient) => (
            <div
              key={patient.id}
              className="flex items-center justify-between p-3 border border-slate-600 rounded-lg bg-slate-700/50 hover:bg-slate-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-teal-500/20 rounded-full border border-teal-500/30">
                  <User className="h-4 w-4 text-teal-400" />
                </div>
                <div>
                  <p className="font-medium text-white">{patient.name}</p>
                  <p className="text-sm text-slate-400">
                    Age: {patient.age} • {patient.condition}
                  </p>
                  <p className="text-xs text-slate-500">Last visit: {patient.lastVisit}</p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
              >
                <Eye className="h-4 w-4 mr-1" />
                View
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
