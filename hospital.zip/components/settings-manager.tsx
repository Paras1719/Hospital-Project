"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import {
  Save,
  Eye,
  EyeOff,
  ChevronDown,
  ChevronUp,
  Lock,
  Bell,
  ClipboardList,
  Database,
  FileText,
  User,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SettingsManager() {
  const [showPassword, setShowPassword] = useState(false)
  const [activeTab, setActiveTab] = useState("profile")
  const [settings, setSettings] = useState({
    // Profile Settings
    doctorName: "Dr. John Smith",
    email: "dr.johnsmith@healthcare.com",
    phone: "+1 (555) 123-4567",
    specialization: "Cardiology",
    qualification: "MD, MBBS",

    // Security Settings
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
    twoFactorAuth: false,

    // Clinic Settings
    clinicName: "Heart Care Clinic",
    clinicAddress: "123 Medical Street, Health City, HC 12345",
    clinicPhone: "+1 (555) 123-4567",
    clinicEmail: "info@heartcareclinic.com",
    clinicHours: "Mon-Fri: 8:00 AM - 5:00 PM",

    // Notification Settings
    emailNotifications: true,
    smsNotifications: false,
    appointmentReminders: true,
    prescriptionReadyAlerts: true,
    labResultAlerts: false,

    // System Settings
    autoBackup: true,
    backupFrequency: "daily",
    dataRetention: "5", // years
    theme: "dark",

    // Prescription Settings
    defaultInstructions: "Take as prescribed by your doctor. Contact clinic if you experience any side effects.",
    prescriptionFooter: "This prescription is computer generated and does not require signature.",
    defaultPharmacy: "Main Street Pharmacy",
  })

  const [isSaving, setIsSaving] = useState(false)
  const [expandedCards, setExpandedCards] = useState<Record<string, boolean>>({
    profile: true,
    security: true,
    clinic: true,
    notifications: true,
    system: true,
    prescriptions: true,
  })

  const toggleCard = (cardName: string) => {
    setExpandedCards((prev) => ({
      ...prev,
      [cardName]: !prev[cardName],
    }))
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      alert("Settings saved successfully!")
    } finally {
      setIsSaving(false)
    }
  }

  const handlePasswordChange = () => {
    if (settings.newPassword !== settings.confirmPassword) {
      alert("New passwords do not match!")
      return
    }
    if (settings.newPassword.length < 8) {
      alert("Password must be at least 8 characters long!")
      return
    }
    // Change password logic
    alert("Password changed successfully!")
    setSettings({
      ...settings,
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    })
  }

  const SettingCard = ({
    title,
    icon: Icon,
    children,
    cardName,
    className,
  }: {
    title: string
    icon: React.ComponentType<{ className?: string }>
    children: React.ReactNode
    cardName: string
    className?: string
  }) => (
    <Card className={cn("bg-slate-800/80 border-slate-700", className)}>
      <CardHeader
        className="cursor-pointer hover:bg-slate-700/50 transition-colors"
        onClick={() => toggleCard(cardName)}
      >
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white">
            <Icon className="h-5 w-5 text-emerald-400" />
            {title}
          </CardTitle>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-white">
            {expandedCards[cardName] ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      {expandedCards[cardName] && <CardContent className="space-y-4 pt-0">{children}</CardContent>}
    </Card>
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">System Settings</h1>
          <p className="text-slate-400">Configure your practice management system</p>
        </div>
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
        >
          {isSaving ? (
            <>
              <svg
                className="animate-spin h-4 w-4 mr-2"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save All Changes
            </>
          )}
        </Button>
      </div>

      <div className="space-y-6">
        {/* Profile Settings */}
        <SettingCard title="Profile Settings" icon={User} cardName="profile">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Doctor Name</Label>
              <Input
                value={settings.doctorName}
                onChange={(e) => setSettings({ ...settings, doctorName: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Specialization</Label>
              <Input
                value={settings.specialization}
                onChange={(e) => setSettings({ ...settings, specialization: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Email</Label>
              <Input
                type="email"
                value={settings.email}
                onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Phone</Label>
              <Input
                value={settings.phone}
                onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Qualifications</Label>
              <Input
                value={settings.qualification}
                onChange={(e) => setSettings({ ...settings, qualification: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
          </div>
        </SettingCard>

        {/* Security Settings */}
        <SettingCard title="Security Settings" icon={Lock} cardName="security">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Current Password</Label>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={settings.currentPassword}
                  onChange={(e) => setSettings({ ...settings, currentPassword: e.target.value })}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent text-slate-400 hover:text-slate-300"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">New Password</Label>
              <Input
                type="password"
                value={settings.newPassword}
                onChange={(e) => setSettings({ ...settings, newPassword: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Confirm New Password</Label>
              <Input
                type="password"
                value={settings.confirmPassword}
                onChange={(e) => setSettings({ ...settings, confirmPassword: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="flex items-center justify-between pt-2 p-4 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="space-y-1">
                <Label className="text-slate-300">Two-Factor Authentication</Label>
                <p className="text-sm text-slate-400">Add an extra layer of security to your account</p>
              </div>
              <Switch
                checked={settings.twoFactorAuth}
                onCheckedChange={(checked) => setSettings({ ...settings, twoFactorAuth: checked })}
              />
            </div>
            <Button
              onClick={handlePasswordChange}
              variant="outline"
              className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
              disabled={!settings.currentPassword || !settings.newPassword || !settings.confirmPassword}
            >
              Change Password
            </Button>
          </div>
        </SettingCard>

        {/* Clinic Settings */}
        <SettingCard title="Clinic Settings" icon={ClipboardList} cardName="clinic">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Clinic Name</Label>
              <Input
                value={settings.clinicName}
                onChange={(e) => setSettings({ ...settings, clinicName: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Clinic Phone</Label>
              <Input
                value={settings.clinicPhone}
                onChange={(e) => setSettings({ ...settings, clinicPhone: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label className="text-slate-300">Clinic Address</Label>
              <Textarea
                value={settings.clinicAddress}
                onChange={(e) => setSettings({ ...settings, clinicAddress: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Clinic Email</Label>
              <Input
                type="email"
                value={settings.clinicEmail}
                onChange={(e) => setSettings({ ...settings, clinicEmail: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Operating Hours</Label>
              <Input
                value={settings.clinicHours}
                onChange={(e) => setSettings({ ...settings, clinicHours: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
          </div>
        </SettingCard>

        {/* Notification Settings */}
        <SettingCard title="Notification Settings" icon={Bell} cardName="notifications">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="space-y-1">
                <Label className="text-slate-300">Email Notifications</Label>
                <p className="text-sm text-slate-400">Receive important updates via email</p>
              </div>
              <Switch
                checked={settings.emailNotifications}
                onCheckedChange={(checked) => setSettings({ ...settings, emailNotifications: checked })}
              />
            </div>
            <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="space-y-1">
                <Label className="text-slate-300">SMS Notifications</Label>
                <p className="text-sm text-slate-400">Get text message alerts</p>
              </div>
              <Switch
                checked={settings.smsNotifications}
                onCheckedChange={(checked) => setSettings({ ...settings, smsNotifications: checked })}
              />
            </div>
            <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="space-y-1">
                <Label className="text-slate-300">Appointment Reminders</Label>
                <p className="text-sm text-slate-400">Automatic reminders for upcoming appointments</p>
              </div>
              <Switch
                checked={settings.appointmentReminders}
                onCheckedChange={(checked) => setSettings({ ...settings, appointmentReminders: checked })}
              />
            </div>
            <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="space-y-1">
                <Label className="text-slate-300">Prescription Ready Alerts</Label>
                <p className="text-sm text-slate-400">Notify when prescriptions are ready</p>
              </div>
              <Switch
                checked={settings.prescriptionReadyAlerts}
                onCheckedChange={(checked) => setSettings({ ...settings, prescriptionReadyAlerts: checked })}
              />
            </div>
            <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="space-y-1">
                <Label className="text-slate-300">Lab Result Alerts</Label>
                <p className="text-sm text-slate-400">Get notified when lab results arrive</p>
              </div>
              <Switch
                checked={settings.labResultAlerts}
                onCheckedChange={(checked) => setSettings({ ...settings, labResultAlerts: checked })}
              />
            </div>
          </div>
        </SettingCard>

        {/* System Settings */}
        <SettingCard title="System Settings" icon={Database} cardName="system">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="space-y-1">
                <Label className="text-slate-300">Auto Backup</Label>
                <p className="text-sm text-slate-400">Automatically backup patient data</p>
              </div>
              <Switch
                checked={settings.autoBackup}
                onCheckedChange={(checked) => setSettings({ ...settings, autoBackup: checked })}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Backup Frequency</Label>
              <Select
                value={settings.backupFrequency}
                onValueChange={(value) => setSettings({ ...settings, backupFrequency: value })}
              >
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="daily" className="text-white hover:bg-slate-700">
                    Daily
                  </SelectItem>
                  <SelectItem value="weekly" className="text-white hover:bg-slate-700">
                    Weekly
                  </SelectItem>
                  <SelectItem value="monthly" className="text-white hover:bg-slate-700">
                    Monthly
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Data Retention (Years)</Label>
              <Input
                type="number"
                value={settings.dataRetention}
                onChange={(e) => setSettings({ ...settings, dataRetention: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Theme</Label>
              <Select value={settings.theme} onValueChange={(value) => setSettings({ ...settings, theme: value })}>
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:border-emerald-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="light" className="text-white hover:bg-slate-700">
                    Light
                  </SelectItem>
                  <SelectItem value="dark" className="text-white hover:bg-slate-700">
                    Dark
                  </SelectItem>
                  <SelectItem value="system" className="text-white hover:bg-slate-700">
                    System
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </SettingCard>

        {/* Prescription Settings */}
        <SettingCard title="Prescription Settings" icon={FileText} cardName="prescriptions">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Default Pharmacy</Label>
              <Input
                value={settings.defaultPharmacy}
                onChange={(e) => setSettings({ ...settings, defaultPharmacy: e.target.value })}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Default Instructions</Label>
              <Textarea
                value={settings.defaultInstructions}
                onChange={(e) => setSettings({ ...settings, defaultInstructions: e.target.value })}
                rows={3}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Prescription Footer</Label>
              <Textarea
                value={settings.prescriptionFooter}
                onChange={(e) => setSettings({ ...settings, prescriptionFooter: e.target.value })}
                rows={2}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
              />
            </div>
          </div>
        </SettingCard>
      </div>
    </div>
  )
}
