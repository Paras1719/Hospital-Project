"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Edit, Save, X, Mail, Phone, MapPin, BriefcaseMedical, Award, Clock, User } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Type safety for profile data
interface DoctorProfile {
  name: string
  specialization: string
  qualification: string
  experience: string
  clinic: string
  address: string
  phone: string
  email: string
  about: string
  avatar?: string
}

export default function DoctorProfile() {
  const [isEditing, setIsEditing] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [profile, setProfile] = useState<DoctorProfile>({
    name: "Dr. John Smith",
    specialization: "Cardiologist",
    qualification: "MBBS, MD (Cardiology)",
    experience: "15 years",
    clinic: "Heart Care Clinic",
    address: "123 Medical Street, Health City, HC 12345",
    phone: "+1 (555) 123-4567",
    email: "dr.johnsmith@healthcare.com",
    about:
      "Experienced cardiologist specializing in preventive cardiology and heart disease management. Committed to providing personalized care using evidence-based practices.",
    avatar: "/avatars/doctor-01.jpg",
  })

  const handleSave = async () => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setIsEditing(false)
      // In production: await saveProfileToBackend(profile)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCancel = () => {
    setIsEditing(false)
  }

  const ProfileField = ({
    label,
    value,
    icon: Icon,
    editing,
    onChange,
    textarea = false,
    type = "text",
  }: {
    label: string
    value: string
    icon?: React.ComponentType<{ className?: string }>
    editing: boolean
    onChange: (value: string) => void
    textarea?: boolean
    type?: string
  }) => (
    <div className="space-y-2">
      <Label className="flex items-center gap-2 text-muted-foreground">
        {Icon && <Icon className="h-4 w-4" />}
        {label}
      </Label>
      {editing ? (
        textarea ? (
          <Textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="min-h-[80px] bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
          />
        ) : (
          <Input
            type={type}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500"
          />
        )
      ) : (
        <p className="text-slate-300">{value || "Not provided"}</p>
      )}
    </div>
  )

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-slate-800/20 to-slate-700/20 border-b border-slate-700">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 border-2 border-white shadow">
              <AvatarImage src={profile.avatar || "/placeholder.svg"} />
              <AvatarFallback className="bg-emerald-500/20 text-emerald-400">
                {profile.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-2xl">{profile.name}</CardTitle>
              <p className="text-emerald-400 font-medium">{profile.specialization}</p>
            </div>
          </div>
          {!isEditing ? (
            <Button onClick={() => setIsEditing(true)} variant="outline" className="gap-2">
              <Edit className="h-4 w-4" />
              Edit Profile
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={isLoading} className="gap-2">
                {isLoading ? (
                  <>
                    <svg
                      className="animate-spin h-4 w-4"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Save
                  </>
                )}
              </Button>
              <Button onClick={handleCancel} variant="outline" disabled={isLoading}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <ProfileField
              label="Full Name"
              value={profile.name}
              icon={User}
              editing={isEditing}
              onChange={(value) => setProfile({ ...profile, name: value })}
            />

            <ProfileField
              label="Specialization"
              value={profile.specialization}
              icon={BriefcaseMedical}
              editing={isEditing}
              onChange={(value) => setProfile({ ...profile, specialization: value })}
            />

            <ProfileField
              label="Qualification"
              value={profile.qualification}
              icon={Award}
              editing={isEditing}
              onChange={(value) => setProfile({ ...profile, qualification: value })}
            />

            <ProfileField
              label="Experience"
              value={profile.experience}
              icon={Clock}
              editing={isEditing}
              onChange={(value) => setProfile({ ...profile, experience: value })}
            />
          </div>

          <div className="space-y-6">
            <ProfileField
              label="Clinic Name"
              value={profile.clinic}
              icon={MapPin}
              editing={isEditing}
              onChange={(value) => setProfile({ ...profile, clinic: value })}
            />

            <ProfileField
              label="Address"
              value={profile.address}
              icon={MapPin}
              editing={isEditing}
              onChange={(value) => setProfile({ ...profile, address: value })}
              textarea
            />

            <ProfileField
              label="Phone"
              value={profile.phone}
              icon={Phone}
              editing={isEditing}
              onChange={(value) => setProfile({ ...profile, phone: value })}
              type="tel"
            />

            <ProfileField
              label="Email"
              value={profile.email}
              icon={Mail}
              editing={isEditing}
              onChange={(value) => setProfile({ ...profile, email: value })}
              type="email"
            />
          </div>
        </div>

        <div className="mt-8">
          <ProfileField
            label="About"
            value={profile.about}
            editing={isEditing}
            onChange={(value) => setProfile({ ...profile, about: value })}
            textarea
          />
        </div>
      </CardContent>
    </Card>
  )
}
