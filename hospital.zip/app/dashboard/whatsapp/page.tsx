import DashboardLayout from "@/components/dashboard-layout"
import WhatsAppManager from "@/components/whatsapp-manager"

export default function WhatsAppPage() {
  return (
    <DashboardLayout>
      <WhatsAppManager />
    </DashboardLayout>
  )
}
