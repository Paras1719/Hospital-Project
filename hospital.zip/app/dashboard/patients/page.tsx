import DashboardLayout from "@/components/dashboard-layout"
import PatientManager from "@/components/patient-manager"

export default function PatientsPage() {
  return (
    <DashboardLayout>
      <PatientManager />
    </DashboardLayout>
  )
}
