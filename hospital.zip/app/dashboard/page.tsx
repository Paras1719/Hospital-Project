import DashboardLayout from "@/components/dashboard-layout"
import DoctorProfile from "@/components/doctor-profile"
import QuickStats from "@/components/quick-stats"
import RecentPatients from "@/components/recent-patients"
import UpcomingAppointments from "@/components/upcoming-appointments"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Bell, CalendarPlus, TrendingUp, Users, Activity, Heart, Award, Zap, Sparkles } from "lucide-react"

export default function DashboardPage() {
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    timeZone: "UTC",
  })

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Welcome Header */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-800 via-slate-700 to-slate-800 p-8 text-white border border-slate-600">
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-cyan-500/10"></div>
          <div className="absolute top-4 right-4 opacity-20">
            <Heart className="h-32 w-32 text-emerald-400" />
          </div>
          <div className="relative">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="h-6 w-6 text-amber-400" />
                  <h1 className="text-4xl font-bold">Good Morning, Doctor! ☀️</h1>
                </div>
                <p className="text-xl text-emerald-200 mb-4">{today} • Ready to make a difference today?</p>
                <div className="flex items-center gap-6 text-sm">
                  <div className="flex items-center gap-2 bg-slate-700/50 px-3 py-1 rounded-full border border-slate-600">
                    <Users className="h-4 w-4 text-emerald-400" />
                    <span>24 patients scheduled</span>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-700/50 px-3 py-1 rounded-full border border-slate-600">
                    <Activity className="h-4 w-4 text-amber-400" />
                    <span>3 urgent cases</span>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-700/50 px-3 py-1 rounded-full border border-slate-600">
                    <Award className="h-4 w-4 text-teal-400" />
                    <span>98% satisfaction rate</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="secondary"
                  className="gap-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border-emerald-500/30"
                >
                  <CalendarPlus className="h-4 w-4" />
                  Quick Schedule
                </Button>
                <Button
                  variant="secondary"
                  className="gap-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border-amber-500/30"
                >
                  <Bell className="h-4 w-4" />
                  Notifications
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="group hover:shadow-2xl transition-all duration-300 cursor-pointer border-2 border-emerald-500/30 hover:border-emerald-500/50 bg-slate-800/80">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-emerald-500/30 transition-colors border border-emerald-500/30">
                <CalendarPlus className="h-6 w-6 text-emerald-400" />
              </div>
              <h3 className="font-semibold text-white">New Appointment</h3>
              <p className="text-sm text-slate-400 mt-1">Schedule a patient visit</p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-2xl transition-all duration-300 cursor-pointer border-2 border-teal-500/30 hover:border-teal-500/50 bg-slate-800/80">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-teal-500/20 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-teal-500/30 transition-colors border border-teal-500/30">
                <Users className="h-6 w-6 text-teal-400" />
              </div>
              <h3 className="font-semibold text-white">Add Patient</h3>
              <p className="text-sm text-slate-400 mt-1">Register new patient</p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-2xl transition-all duration-300 cursor-pointer border-2 border-cyan-500/30 hover:border-cyan-500/50 bg-slate-800/80">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-cyan-500/20 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-cyan-500/30 transition-colors border border-cyan-500/30">
                <Zap className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="font-semibold text-white">Quick Prescription</h3>
              <p className="text-sm text-slate-400 mt-1">Create prescription</p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-2xl transition-all duration-300 cursor-pointer border-2 border-amber-500/30 hover:border-amber-500/50 bg-slate-800/80">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-amber-500/20 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-amber-500/30 transition-colors border border-amber-500/30">
                <TrendingUp className="h-6 w-6 text-amber-400" />
              </div>
              <h3 className="font-semibold text-white">Analytics</h3>
              <p className="text-sm text-slate-400 mt-1">View practice insights</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <DoctorProfile />
        <QuickStats />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <UpcomingAppointments />
          <RecentPatients />
        </div>

        {/* Motivational Footer */}
        <Card className="bg-gradient-to-r from-slate-800 to-slate-700 border-2 border-emerald-500/30">
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Heart className="h-6 w-6 text-amber-400 animate-pulse" />
              <h3 className="text-xl font-bold text-white">Making Healthcare Better, One Patient at a Time</h3>
              <Heart className="h-6 w-6 text-amber-400 animate-pulse" />
            </div>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Your dedication to patient care makes a real difference. Every consultation, every prescription, every
              moment of care contributes to healthier communities. Keep up the amazing work! 🌟
            </p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
