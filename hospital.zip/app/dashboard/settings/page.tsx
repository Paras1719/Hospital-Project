import DashboardLayout from "@/components/dashboard-layout"
import SettingsManager from "@/components/settings-manager"

export default function SettingsPage() {
  return (
    <DashboardLayout>
      <SettingsManager />
    </DashboardLayout>
  )
}
