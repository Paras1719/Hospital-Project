import DashboardLayout from "@/components/dashboard-layout"
import PatientHistory from "@/components/patient-history"

export default function HistoryPage() {
  return (
    <DashboardLayout>
      <PatientHistory />
    </DashboardLayout>
  )
}
