import DashboardLayout from "@/components/dashboard-layout"
import PrescriptionManager from "@/components/prescription-manager"

export default function PrescriptionsPage() {
  return (
    <DashboardLayout>
      <PrescriptionManager />
    </DashboardLayout>
  )
}
