import DashboardLayout from "@/components/dashboard-layout"
import ScheduleManager from "@/components/schedule-manager"

export default function SchedulePage() {
  return (
    <DashboardLayout>
      <ScheduleManager />
    </DashboardLayout>
  )
}
